package com.example1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class GraphCalculator extends AppCompatActivity {

    //doamne ajuta ce o sa fie aici
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_calculator);
        Button Start = (Button) findViewById(R.id.ComputeAllGraphButton);
        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                and_so_it_begins();
            }
        });
    }
    private double evaluate(int left,int right,String s)
    {
        int i;
        for(i=left;i<=right;++i)
            System.out.println(s.charAt(i));
        return 0;
    }
    private  void and_so_it_begins(){
        EditText Input = (EditText) findViewById(R.id.InputFunction);
        String InputStr = Input.getText().toString();
        int len = InputStr.length();

        evaluate(0,len - 1,InputStr);

    }
}